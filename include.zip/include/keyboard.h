#ifndef KEYBOARD_H
#define KEYBOARD_H

extern void keyboard_initialize();
extern void keyboard_handler(char code);


#endif